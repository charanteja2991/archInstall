-- Hyprland Lua config (converted from hyprland.conf)
-- Refer to the wiki: https://wiki.hypr.land/Configuring/Start/
-- Requires Hyprland >= 0.55

------------------
---- MONITORS ----
------------------

-- See https://wiki.hypr.land/Configuring/Basics/Monitors/
 hl.monitor({ output = "VGA-1", mode = "1920x1080@60", position = "0x0", scale = 1 })
-- hl.monitor({ output = "VGA-1", mode = "1600x900@60", position = "0x0", scale = 1 })
-- hl.monitor({ output = "VGA-1", mode = "1280x720@60", position = "0x0", scale = 1 })


---------------------
---- MY PROGRAMS ----
---------------------

local terminal    = "kitty"
local fileManager = "nautilus"
local menu        = os.getenv("HOME") .. "/.config/rofi/launchers/type-7/launcher.sh"


-------------------
---- AUTOSTART ----
-------------------

-- See https://wiki.hypr.land/Configuring/Basics/Autostart/
hl.on("hyprland.start", function()
    hl.exec_cmd("waybar")
    hl.exec_cmd("swaync")
    hl.exec_cmd("hyprctl setcursor Breeze_Light 24")
    hl.exec_cmd("swaybg -i " .. os.getenv("HOME") .. "/.config/hypr/1361560.png")
end)


-------------------------------
---- ENVIRONMENT VARIABLES ----
-------------------------------

hl.env("XCURSOR_SIZE",    "24")
hl.env("HYPRCURSOR_SIZE", "24")


-----------------------
---- LOOK AND FEEL ----
-----------------------

hl.config({
    general = {
        gaps_in  = 2,
        gaps_out = 5,
        no_focus_fallback = true,
        border_size = 2,

        col = {
            active_border   = { colors = { "rgba(00b3ffee)", "rgba(d127ffee)" }, angle = 45 },
            inactive_border = "rgba(595959aa)",
        },

        resize_on_border = false,
        allow_tearing    = false,
        layout           = "dwindle",
    },

    decoration = {
        rounding       = 15,
        rounding_power = 2.0,

        active_opacity   = 1.0,
        inactive_opacity = 0.75,

        shadow = {
            enabled      = false,
            --range        = 4,
            --render_power = 3,
            --color        = 0xee1a1a1a,
        },

        blur = {
            enabled   = true,
            size      = 3,
            passes    = 1,
            vibrancy  = 0.1696,
        },
    },

    animations = {
        enabled = true,
    },

    dwindle = {
        preserve_split = true,
    },

    master = {
        new_status = "master",
    },

    misc = {
        force_default_wallpaper = -1,
        disable_hyprland_logo   = false,
    },

    input = {
        kb_layout  = "us",
        kb_variant = "",
        kb_model   = "",
        kb_options = "",
        kb_rules   = "",
        numlock_by_default = true,

        follow_mouse  = 1,
        accel_profile = "flat",
        sensitivity   = 0,

        touchpad = {
            natural_scroll = false,
        },
    },
})


--------------------
---- ANIMATIONS ----
--------------------

-- Bezier curves
hl.curve("wind",   { type = "bezier", points = { { 0.05, 0.9  }, { 0.1,  1.05 } } })
hl.curve("winIn",  { type = "bezier", points = { { 0.1,  1.1  }, { 0.1,  1.1  } } })
hl.curve("winOut", { type = "bezier", points = { { 0.3, -0.3  }, { 0,    1    } } })
hl.curve("liner",  { type = "bezier", points = { { 1,    1    }, { 1,    1    } } })

-- Animations
hl.animation({ leaf = "windows",     enabled = true, speed = 3, bezier = "wind",    style = "slide" })
hl.animation({ leaf = "windowsIn",   enabled = true, speed = 3, bezier = "winIn",   style = "slide" })
hl.animation({ leaf = "windowsOut",  enabled = true, speed = 3, bezier = "winOut",  style = "slide" })
hl.animation({ leaf = "windowsMove", enabled = true, speed = 5, bezier = "wind",    style = "slide" })
hl.animation({ leaf = "border",      enabled = true, speed = 1, bezier = "liner" })
hl.animation({ leaf = "borderangle", enabled = true, speed = 1, bezier = "liner" })
hl.animation({ leaf = "fade",        enabled = true, speed = 2, bezier = "default" })
hl.animation({ leaf = "workspaces",  enabled = true, speed = 6, bezier = "wind" })


---------------
---- INPUT ----
---------------

-- Gesture: 3-finger horizontal swipe to switch workspaces
hl.gesture({
    fingers   = 3,
    direction = "horizontal",
    action    = "workspace",
})

-- Per-device config
hl.device({
    name        = "epic-mouse-v1",
    sensitivity = -0.5,
})


---------------------
---- KEYBINDINGS ----
---------------------

local mainMod  = "SUPER"
-- Music Player
hl.bind(mainMod  .. " + M",                    hl.dsp.exec_cmd("strawberry"))

-- Clipboard
hl.bind(mainMod  .. " + V",                    hl.dsp.exec_cmd("cursor-clip"))

-- Kate unsaved file
hl.bind(mainMod  .. " + N",                    hl.dsp.exec_cmd("kate -n Untitled"))

-- Workspace navigation
hl.bind(mainMod .. " + ALT + TAB",             hl.dsp.window.move({ workspace = "+1" }))
hl.bind(mainMod .. " + ALT + SHIFT + TAB",     hl.dsp.window.move({ workspace = "-1" }))

hl.bind(mainMod .. " + TAB",                   hl.dsp.focus({ workspace = "+1" }))
hl.bind(mainMod .. " + SHIFT + TAB",           hl.dsp.focus({ workspace = "-1" }))

-- App launchers
hl.bind(mainMod  .. " + B",                    hl.dsp.exec_cmd("firefox"))
hl.bind(mainMod  .. " + F4",                   hl.dsp.exec_cmd(os.getenv("HOME") .. "/.config/waybar/scripts/archmenu.sh"))

-- Screenshots
hl.bind(mainMod  .. " + SHIFT + S",            hl.dsp.exec_cmd("hyprshot -m region"))
hl.bind(mainMod  .. " + PRINT",                hl.dsp.exec_cmd("hyprshot -m window"))

-- Terminal
hl.bind("CTRL + ALT + T",                      hl.dsp.exec_cmd(terminal))
hl.bind(mainMod .. " + T",                     hl.dsp.exec_cmd(terminal))

-- Close window
hl.bind(mainMod  .. " + SHIFT + C",            hl.dsp.window.close())
hl.bind("ALT + F4",                            hl.dsp.window.close())

-- Session control
hl.bind(mainMod .. " + CTRL + SHIFT + L",      hl.dsp.exec_cmd("command -v hyprshutdown >/dev/null 2>&1 && hyprshutdown || hyprctl dispatch 'hl.dsp.exit()'"))
hl.bind(mainMod  .. " + SHIFT + F4",           hl.dsp.exec_cmd("shutdown now"))
hl.bind(mainMod .. " + CTRL + SHIFT + R",      hl.dsp.exec_cmd("reboot"))

-- File manager
hl.bind(mainMod  .. " + E",                    hl.dsp.exec_cmd(fileManager))

-- Float toggle
hl.bind(mainMod .. " + SHIFT + V",             hl.dsp.window.float({ action = "toggle" }))

-- App menu
hl.bind("ALT + SPACE",                         hl.dsp.exec_cmd(menu))

-- Dwindle
hl.bind(mainMod .. " + SHIFT + P",             hl.dsp.window.pseudo())

-- Focus movement — arrow keys
hl.bind(mainMod  .. " + left",                 hl.dsp.focus({ direction = "left"  }))
hl.bind(mainMod  .. " + right",                hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod  .. " + up",                   hl.dsp.focus({ direction = "up"    }))
hl.bind(mainMod  .. " + down",                 hl.dsp.focus({ direction = "down"  }))

-- Focus movement — WASD
hl.bind(mainMod  .. " + A",                    hl.dsp.focus({ direction = "left"  }))
hl.bind(mainMod  .. " + D",                    hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod  .. " + W",                    hl.dsp.focus({ direction = "up"    }))
hl.bind(mainMod  .. " + S",                    hl.dsp.focus({ direction = "down"  }))

-- Focus movement — IJKL
hl.bind(mainMod  .. " + J",                    hl.dsp.focus({ direction = "left"  }))
hl.bind(mainMod  .. " + L",                    hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod  .. " + I",                    hl.dsp.focus({ direction = "up"    }))
hl.bind(mainMod  .. " + K",                    hl.dsp.focus({ direction = "down"  }))

-- Switch / move to workspace 1-10
for i = 1, 10 do
    local key = tostring(i % 10) -- 10 -> "0"

    hl.bind(mainMod  .. " + " .. key,           hl.dsp.focus({ workspace = i }))
    hl.bind(mainMod  .. " + SHIFT + " .. key,   hl.dsp.window.move({ workspace = i }))
end

-- Scroll through workspaces with mouse wheel
hl.bind(mainMod  .. " + mouse_down",           hl.dsp.focus({ workspace = "e+1" }))
hl.bind(mainMod  .. " + mouse_up",             hl.dsp.focus({ workspace = "e-1" }))

-- Move/resize windows with mouse drag
hl.bind(mainMod  .. " + mouse:272",            hl.dsp.window.drag(),   { mouse = true })
hl.bind(mainMod  .. " + mouse:273",            hl.dsp.window.resize(), { mouse = true })

-- Multimedia / brightness keys

------------------------------------------ MY COMMANDS BTW ------------------------------------------

-- ARROW KEYS
hl.bind(mainMod .. " + CTRL + right", hl.dsp.exec_cmd("playerctl next"), { locked = true })
hl.bind(mainMod .. " + CTRL + left", hl.dsp.exec_cmd("playerctl previous"), { locked = true })
hl.bind(mainMod .. " + CTRL + up",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"),  { locked = true, repeating = true })
hl.bind(mainMod .. " + CTRL + down",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),     { locked = true, repeating = true })

-- WSAD KEYS
hl.bind(mainMod .. " + CTRL + D", hl.dsp.exec_cmd("playerctl next"), { locked = true })
hl.bind(mainMod .. " + CTRL + A", hl.dsp.exec_cmd("playerctl previous"), { locked = true })
hl.bind(mainMod .. " + CTRL + W",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"),  { locked = true, repeating = true })
hl.bind(mainMod .. " + CTRL + S",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),     { locked = true, repeating = true })

-- IJKL KEYS
hl.bind(mainMod .. " + CTRL + L", hl.dsp.exec_cmd("playerctl next"), { locked = true })
hl.bind(mainMod .. " + CTRL + J", hl.dsp.exec_cmd("playerctl previous"), { locked = true })
hl.bind(mainMod .. " + CTRL + I",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"),  { locked = true, repeating = true })
hl.bind(mainMod .. " + CTRL + K",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),     { locked = true, repeating = true })

-- PAUSE AND PLAY
hl.bind(mainMod .. " + CTRL + SPACE", hl.dsp.exec_cmd("playerctl play-pause"),  { locked = true })

-----------------------------------------------------------------------------------------------------

------------------------------------------ DEFAULT COMMANDS ------------------------------------------
hl.bind("XF86AudioRaiseVolume",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"),  { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),        { locked = true, repeating = true })
hl.bind("XF86AudioMute",         hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"),       { locked = true, repeating = true })
hl.bind("XF86AudioMicMute",      hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle"),     { locked = true, repeating = true })
hl.bind("XF86MonBrightnessUp",   hl.dsp.exec_cmd("brightnessctl -e4 -n2 set 5%+"),                    { locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl -e4 -n2 set 5%-"),                    { locked = true, repeating = true })

-- Playerctl
hl.bind("XF86AudioNext",  hl.dsp.exec_cmd("playerctl next"),        { locked = true })
hl.bind("XF86AudioPause", hl.dsp.exec_cmd("playerctl play-pause"),  { locked = true })
hl.bind("XF86AudioPlay",  hl.dsp.exec_cmd("playerctl play-pause"),  { locked = true })
hl.bind("XF86AudioPrev",  hl.dsp.exec_cmd("playerctl previous"),    { locked = true })
-------------------------------------------------------------------------------------------------------

--------------------------------
---- WINDOWS AND WORKSPACES ----
--------------------------------

-- Ignore maximize requests from all apps
hl.window_rule({
    name           = "suppress-maximize-events",
    match          = { class = ".*" },
    suppress_event = "maximize",
})

-- Fix some dragging issues with XWayland
hl.window_rule({
    name  = "fix-xwayland-drags",
    match = {
        class      = "^$",
        title      = "^$",
        xwayland   = true,
        float      = true,
        fullscreen = false,
        pin        = false,
    },
    no_focus = true,
})

-- Hyprland-run float positioning
hl.window_rule({
    name  = "move-hyprland-run",
    match = { class = "hyprland-run" },
    move  = "20 monitor_h-120",
    float = true,
})

-- HyprMod managed settings
require("hyprland-gui")
