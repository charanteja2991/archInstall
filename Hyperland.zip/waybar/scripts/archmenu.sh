#!/bin/bash

options="  Shutdown\n  Restart\n  Logout\n  New Workspace"
chosen=$(echo -e "$options" | ~/.config/rofi/launchers/type-6/menulauncher.sh)

case "$chosen" in
    "  Shutdown") systemctl poweroff ;;
    "  Restart") systemctl reboot ;;
    "  Logout") hyprctl dispatch exit ;;
    "  New Workspace") hyprctl dispatch workspace +1 ;;
esac
